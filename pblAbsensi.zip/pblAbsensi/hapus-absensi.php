<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
    require 'koneksi.php';

    $get_kode = $_GET['id_absensi'];

    $sql = "DELETE FROM absensi WHERE id_absensi=$get_kode";
    
        if ($db->query($sql) === TRUE ){
            header("Location: table-absensi.php");
        }
        else{
            echo "Gagal hapus data! ". $db->error;
        }
    
?>