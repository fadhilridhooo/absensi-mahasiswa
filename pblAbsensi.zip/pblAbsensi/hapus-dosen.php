<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
    require 'koneksi.php';

    $get_kode = $_GET['kode_dosen'];

    $sql = "DELETE FROM dosen WHERE kode_dosen=$get_kode";
    
        if ($db->query($sql) === TRUE ){
            header("Location: table-dosen.php");
        }
        else{
            echo "Gagal hapus data! ". $db->error;
        }
    
?>