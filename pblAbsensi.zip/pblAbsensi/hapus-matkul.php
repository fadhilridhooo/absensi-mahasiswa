<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
    require 'koneksi.php';

    $get_kode = $_GET['kode_matkul'];

    $sql = "DELETE FROM matkul WHERE kode_matkul=$get_kode";
    
        if ($db->query($sql) === TRUE ){
            header("Location: table-matkul.php");
        }
        else{
            echo "Gagal hapus data! ". $db->error;
        }
    
?>