<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
    require 'koneksi.php';

    $get_id = $_GET['id_jadwal'];

    $sql = "DELETE FROM jadwal WHERE id_jadwal=$get_id";
    
        if ($db->query($sql) === TRUE ){
            header("Location: table-jadwal.php");
        }
        else{
            echo "Gagal hapus data! ". $db->error;
        }
    
?>