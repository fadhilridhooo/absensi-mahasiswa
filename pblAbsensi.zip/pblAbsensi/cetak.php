<?php
    session_start();
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit;
      }
    require 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Data</title>
</head>
<body>
    
        <h3><center>DATA KEHADIRAN MAHASISWA</center></h3>
        <table>
            <tr>
                <td>Program Studi: D3 MI</td>
                
            </tr>
            <tr>
                <td>Kelas : Semua Kelas</td>
                
            </tr>
        </table>
    

    <table border="1" style="width:100%; border-collapse: collapse;" align="center">
        <tr>
        <th>NO</th>
        <th>HARI</th>
        <th>TANGGAL</th>
        <th>KELAS</th>
        <th>MATKUL</th>
        <th>NIM</th>
        <th>NAMA</th>
        <th>KETERANGAN</th>
        </tr>
        <?php 
             //$query = "SELECT * FROM mahasiswa,prodi WHERE mahasiswa.prodi_id=prodi.id";

            $query = "SELECT * FROM absensi LEFT join mahasiswa on mahasiswa.nim=absensi.nim left join kelas on mahasiswa.id_kelas=kelas.id_kelas
            left join jadwal on kelas.id_kelas=jadwal.id_kelas left join dosen on jadwal.kode_dosen=dosen.kode_dosen LEFT join matkul on jadwal.kode_matkul=matkul.kode_matkul LEFT join kehadiran on kehadiran.id_ket=absensi.id_ket ORDER BY tanggal desc,mahasiswa.nim asc";
            $result = $db->query($query);
            $nomor = 1;
                                                foreach($result as $row) : ?>
                                                    <tr class="table table-success table-striped ">
                                                        <td><?= $nomor++ ?></td>
                                                        <td><?= $row['hari'] ?></td>
                                                        <td><?= $row['tanggal'] ?></td>
                                                        <td><?= $row['nama_kelas'] ?></td>
                                                        <td><?= $row['nama_matkul'] ?></td>

                                                        <td><?= $row['nim'] ?></td>

                                                        <td><?= $row['nama'] ?></td>
                                                        <td><?= $row['ket'] ?></td>                                                      
                                                    </tr>
                                                <?php endforeach ?>

    </table>
    <script>
        window.print();
    </script>

</body>
</html>