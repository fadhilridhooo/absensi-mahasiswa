<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "db_presensi3";

//inisialisasi class mysql menjadi objek
$db = new mysqli($host,$username,$password,$database);

if($db -> connect_error){
    die("Goneksi Gagal !".$db -> connect_error);
}
