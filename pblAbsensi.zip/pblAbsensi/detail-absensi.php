<?php

session_start();

require 'koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
  }



?>


<?php

 


$username = @$_SESSION['username'];
$sql= mysqli_query($db,"SELECT * FROM dosen
 WHERE kode_dosen = '$username'")or die(mysqli_error($db));
$data = mysqli_fetch_array($sql);

$tgl=date("d-m-Y");
$jumlah_dosen=mysqli_num_rows(mysqli_query($koneksi,"select * from dosen where kode_dosen"));
$jumlah_kelas=mysqli_num_rows(mysqli_query($koneksi,"select * from kelas"));
$jumlah_mahasiswa=mysqli_num_rows(mysqli_query($koneksi,"select * from mahasiswa"));



 // tampilkan data mengajar
// $query= mysqli_query("SELECT * FROM jadwal
    
// INNER JOIN matkul ON jadwal.kode_matkul=matkul.kode_matkul
// INNER JOIN kelas ON jadwal.id_kelas=kelas.id_kelas
 //INNER JOIN dosen ON jadwal.kode_dosen=kelas.kode_dosen
 
 
 //WHERE dosen.kode_dosen='$username' AND CURRENT_TIME BETWEEN jadwal.mulai and jadwal.selesai");
    
 
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dasboard</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon">
                    <img src="img/TI-removebg-preview (1).png" style="color: white;"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Tekonologi Informasi></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Kehadiran</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="input-absensi.php">Input Kehadiran</a>
                        <a class="collapse-item" href="table-absensi.php">Daftar Kehadiran</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Data
            </div>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="table-mhs.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Mahasiswa</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="table-dosen.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Dosen</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="table-matkul.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Mata Kuliah</span></a>

            <li class="nav-item">
                <a class="nav-link" href="table-jadwal.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Jadwal</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-warning" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <li class="mt-5">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small "><p id="waktu"></p></span>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1 mt-4">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                            </a>
                            
                        </li>

                        <!-- Nav Item - Messages -->
                        <li class="nav-item dropdown no-arrow mx-1 mt-4">
                            <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-envelope fa-fw"></i>
                            </a>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow mt-4">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?=$_SESSION['username']?></span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="index.php">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a id="logoutLink" class="dropdown-item" href="login.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>

                        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Absensi <?php if($_GET["kelas"] == "1"){echo 'MI 1 A';}elseif($_GET["kelas"] == "2"){echo'MI 1 B';}elseif($_GET["kelas"] == "3"){echo'MI 1 C';}elseif($_GET["kelas"] == "6"){echo'MI 2 A';}elseif($_GET["kelas"] == "7"){echo'MI 2 B';}elseif($_GET["kelas"] == "8"){echo'MI 2 C';}elseif($_GET["kelas"] == "9"){echo'MI 3 A';}elseif($_GET["kelas"] == "10"){echo'MI 3 B';}elseif($_GET["kelas"] == "11"){echo'MI 3 C';} ?>  <?=$_GET["jadwal_absen"].' ('.$tgl.')'?> </h1>

  <!-- DataTales -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Daftar Mahasiswa </h6>
  </div>
  <div class="card-body">             
      <form role="form" action="simpanabsensi.php?id=<?php echo $_GET['kelas'];?>" method="post" name="postform" enctype="multipart/form-data">
    <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr align="center">
            <th>No</th>
            <th>Profil</th>
            <th>NPM</th>
            <th>Nama</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody align="center">
          <?php
          $id_kelas=$_GET['kelas'];
          $sql="SELECT * FROM mahasiswa WHERE id_kelas='$id_kelas'";
          $query=mysqli_query($koneksi,$sql);
          $i = 1;
          while ($data=mysqli_fetch_array($query)){
              $npm=$data["npm"];
              $nama=$data["nama"];
          ?>
          <tr>
            <td><?=$i++;?></td>
            <td><img class="img-profile rounded-circle" style="width:50px;height:50px;" src="img/<?= $data["foto"];?>"></td>
            <td><?= $npm;?></td>
            <td><?= $nama;?></td>
            <td> 
            <label class="radio-inline"><input type="radio" name="<?= 'ket'.$data["npm"];?>" id="<?php echo 'opsi1'.$npm;?>" value="Hadir">Hadir</label>
            <label class="radio-inline"><input type="radio" name="<?= 'ket'.$data["npm"];?>" id="<?php echo 'opsi1'.$npm;?>" value="Absen">Absen</label>
            <label class="radio-inline"><input type="radio" name="<?= 'ket'.$data["npm"];?>" id="<?php echo 'opsi1'.$npm;?>" value="Sakit">Sakit</label>
            <label class="radio-inline"><input type="radio" name="<?= 'ket'.$data["npm"];?>" id="<?php echo 'opsi1'.$npm;?>" value="Izin">Izin</label>

            </td>
          </tr>
          <?php }?>
          </tbody>
      </table>
  </div>
  <button type="submit" class="btn btn-primary mt-4 col-md-2 offset-10">Simpan Data</button>
  </form>
  
  </div>
</div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
   

            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Kelompok 4</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Pilih "Logout" di bawah ini jika Anda siap untuk mengakhiri sesi Anda saat ini.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

    <script>
function updateWaktu() {
    var waktuElement = document.getElementById("waktu");
    var waktu = new Date();
    
    var jam = waktu.getHours();
    var menit = waktu.getMinutes();
    var detik = waktu.getSeconds();

    // Tambahkan nol di depan jika jam, menit, atau detik kurang dari 10
    jam = jam < 10 ? "0" + jam : jam;
    menit = menit < 10 ? "0" + menit : menit;
    detik = detik < 10 ? "0" + detik : detik;

    var tanggal = waktu.getDate();
    var bulan = waktu.getMonth() + 1; // Januari dimulai dari 0
    var tahun = waktu.getFullYear();

    var hariIndex = waktu.getDay();
    var hariArray = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    var hari = hariArray[hariIndex];

    var waktuString = hari + ", " + tanggal + "/" + bulan + "/" + tahun + " - " + jam + ":" + menit ;
    waktuElement.innerHTML = waktuString;
}

// Panggil fungsi updateWaktu setiap detik
setInterval(updateWaktu, 1000);
</script>

</body>

</html>