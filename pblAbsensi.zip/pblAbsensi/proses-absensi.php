<?php
include "koneksi.php";

if ($_GET['proses'] == 'update') {
    if (isset($_POST['submit'])) {
        $id_absensi = $_POST['id_absensi'];
        $id_ket = $_POST['id_ket'];

        // Pastikan $id_jdwl memiliki nilai yang valid
        $id_absensi = isset($_POST['id_absensi']) ? (int)$_POST['id_absensi'] : null;

        // Periksa apakah $id_jdwl memiliki nilai sebelum digunakan
        if ($id_absensi !== null) {
            $query = "UPDATE absensi SET id_ket='$id_ket' WHERE id_absensi=$id_absensi";

            if ($db->query($query) === TRUE) {
                header("Location: table-absensi.php"); // Redirect
            } else {
                echo "Gagal Update Data: " . $db->error;
            }
        } else {
            echo "ID Absensi tidak valid.";
        }
    }
}



if ($_GET['proses'] == 'delete') {
    include "koneksi.php";

    $get_id = isset($_GET['id_absensi']) ? $db->real_escape_string($_GET['id_absensi']) : null;

    // Pastikan $get_id memiliki nilai yang valid
    if ($get_id !== null) {
        $sql = "DELETE FROM absensi WHERE id_absensi='$get_id'";

        if ($db->query($sql) === TRUE) {
            header("Location: table-absensi.php");
            exit(); // Penting untuk menghentikan eksekusi setelah redirect
        } else {
            echo "Gagal menghapus data: " . $db->error;
        }
    } else {
        echo "Kode Kelas tidak valid.";
    }
}
?>
