<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
    require 'koneksi.php';

    $get_nim = $_GET['nim'];

    $sql = "DELETE FROM mahasiswa WHERE nim=$get_nim";
    
        if ($db->query($sql) === TRUE ){
            header("Location: table-mhs.php");
        }
        else{
            echo "Gagal hapus data! ". $db->error;
        }
    
?>