<?php
session_start(); // Start the session

include "koneksi.php";

if (isset($_POST['submit'])) {
    // Mengambil nilai yang dikirim dari inputan form
    date_default_timezone_set("Asia/Jakarta");
    $tgl = date("d-m-Y");
    $hari = date("l");
    $tgl = date("Y-m-d");

    if ($hari == "Sunday") $hari = "Minggu";
    else if ($hari == "Monday") $hari = "Senin";
    else if ($hari == "Tuesday") $hari = "Selasa";
    else if ($hari == "Wednesday") $hari = "Rabu";
    else if ($hari == "Thursday") $hari = "Kamis";
    else if ($hari == "Friday") $hari = "Jumat";
    else if ($hari == "Saturday") $hari = "Sabtu";

    $loggedInUsername = isset($_SESSION['username']) ? $_SESSION['username'] : ''; // Check if $_SESSION['username'] is set
    $id_kelas = isset($_POST['id_kelas']) ? $_POST['id_kelas'] : '';
    $kode_matkul = isset($_POST['kode_matkul']) ? $_POST['kode_matkul'] : '';

    // Use the current timestamp for the "jam" field
    $jam = date("H:i:s");

    // Use prepared statements to prevent SQL injection
    $stmt = $db->prepare("INSERT INTO absensi (id_kelas, kode_matkul, hari, tanggal, nim, id_ket) VALUES (?, ?, ?, ?, ?, ?)");

    // Loop through the submitted attendance data
    foreach ($_POST['kehadiran'] as $nim => $kehadiran) {
        // Use prepared statements to prevent SQL injection for the foreign key
        $stmtKet = $db->prepare("SELECT id_ket FROM kehadiran WHERE ket = ?");
        $stmtKet->bind_param("s", $kehadiran);
        $stmtKet->execute();
        $stmtKet->bind_result($id_ket);
        $stmtKet->fetch();
        $stmtKet->close();

        // Bind parameters
        $stmt->bind_param("sssssi", $id_kelas, $kode_matkul, $hari, $tgl, $nim, $id_ket);

        // Execute the query for each student
        if (!$stmt->execute()) {
            echo "Data gagal disimpan: " . $stmt->error;
            exit; // Stop processing if an error occurs
        }
    }

    $stmt->close(); // Close the prepared statement

    header("Location: table-absensi.php"); // Redirect on success
}
?>